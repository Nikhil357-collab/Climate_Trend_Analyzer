import streamlit as st
import pandas as pd
import plotly.express as px

df = pd.read_csv("data/processed/cleaned_data.csv")

st.title("🌍 Climate Trend Analyzer")

fig = px.line(df, x='date', y='temperature', title="Temperature Trend")
st.plotly_chart(fig)

fig2 = px.line(df, x='date', y='rainfall', title="Rainfall Trend")
st.plotly_chart(fig2)

if 'anomaly' in df.columns:
    anomalies = df[df['anomaly'] == 1]
    st.write("🚨 Anomalies")
    st.dataframe(anomalies)